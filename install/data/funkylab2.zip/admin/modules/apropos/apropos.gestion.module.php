<?	
	
//--------------------------------------------------------------------		
// CREDIT
//--------------------------------------------------------------------

	windowscreate("Funky<font color=\"red\">lab</font> V2",null,null,"debut",null);
		echo
		"<p>Par <a href='http://medcg.free.fr'>Cyril Pereira</a>
		<br/>
		<a href=\"http://www.funkylab.info\" target=\"_blank\">http://www.funkylab.info</a>
		<br/>
		<a href=\"http://www.copyrightdepot.com/rep74/00038690.htm\" target=\"_blank\"><img src='".SKIN."/images/sceau1.gif' border=\"0\"></a><br/>
		   00038690 </p>";
	windowscreate(null,null,null,null,null);
	
//--------------------------------------------------------------------		
// LAMP
//--------------------------------------------------------------------

	windowscreate("L. A. M. P.",null,null,"debut",null);
		echo
		"<p>Ce site fonctionne a �t� r�alis� avec la technologie <a href='http://www.onlamp.com/'>LAMP</a> (Linux, Apache, MySQL & PHP)<br/>
		<a href='http://www.linux.com/'><IMG SRC='image/linux.gif'  border=0></a><a href='http://www.apache.org/'><IMG SRC='image/apache.gif' border=0></a><a href='http://www.mysql.com/'><IMG SRC='image/mysql.gif' border=0></a><a href='http://www.php.net/'><IMG SRC='image/php.gif' border=0></a><br/>
		Optimis� pour Firefox<br/>
		<a href='http://www.mozilla-europe.org/fr/products/firefox/'><IMG SRC='image/firefox.gif' border=0></a></p>";
	windowscreate(null,null,null,null,null);
	
//--------------------------------------------------------------------		
// CREDIT SUP
//--------------------------------------------------------------------

	windowscreate("Cr�dit supl�mentaire",null,null,"debut",null);
		echo
		"JSCookMenu et JSCookTree � Copyright 2002-2005 par Heng Yuan<br/>
		TinyMCE Copyright � 2004 Moxiecode Systems AB<br/>		
		<a href=\"http://tinymce.moxiecode.com?id=powered_by_tinymce_mini\"><img src=\"http://tinymce.sourceforge.net/buttons/tinymce_button.png\" border=\"0\" width=\"80\" height=\"15\" alt=\"Powered by TinyMCE\" /></a></p>
		";
	windowscreate(null,null,null,null,null);
?>