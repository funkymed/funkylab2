			<table border="0" cellspacing="0" cellpadding="0" width="659">
				<tr>
					<td colspan="3" class="bdhaut" valign="middle">
						<table width="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td width="10"></td>
								<td class="textbdhaut">#TITREWIN#</td>
 							</tr>
 						</table>
					</td>
				</tr>
				
				<tr height="5"><td colspan="2"></td></tr>
				
				<tr>
					<td width="210" valign="top" align="center">
						<img SRC="#SKINSITE#/dragwin/img/logo.jpg"/>
					</td>
					
					
					<td class="ligne">
					</td>
					
					<td>
						#COTENUWIN#
					</td>
				</tr>
				<tr height="5"><td colspan="2"></td></tr>
			</table>		