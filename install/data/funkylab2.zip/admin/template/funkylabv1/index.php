<?
		echo "
		<TABLE width=100% cellspacing=\"0\" cellpadding=\"0\">
			<TR>
				<TD width=191><IMG SRC='",SKIN,"/images/bandeau_funkylabtitre.jpg'></TD>
				<TD background='",SKIN,"/images/bandeau_loop.gif'><IMG SRC='",SKIN,"/images/bandeau_loop.gif'></TD>
				<TD width=601><IMG SRC='",SKIN,"/images/bandeau_droite.png'></TD>
			</TR>
		</TABLE>
		";
	include('include/gestion.inc.php');
?>	